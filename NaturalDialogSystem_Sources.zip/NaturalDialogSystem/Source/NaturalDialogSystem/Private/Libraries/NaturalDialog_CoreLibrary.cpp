// Created by Michal Chamula. All rights reserved.


#include "Libraries/NaturalDialog_CoreLibrary.h"
#include "Resources/Resources.h"

TSet<UDataTable*> UNaturalDialog_CoreLibrary::GetListOfDialogDataTables()
{
	// Finds all tables in content
	const TArray<UDataTable*> FoundTables = GetListOfContentObjects_Recursive<UDataTable>();
	
	TSet<UDataTable*> Result;
	Result.Reserve(FoundTables.Num());
	
	for(UDataTable* Table : FoundTables)
	{
		// We sort out tables with correct natural dialog struct
		if(Table && Table->GetRowStruct()->IsChildOf(FNaturalDialogRow::StaticStruct()))
		{
			Result.Add(Table);
		}
	}

	return Result;
}
