// Created by Michal Chamula. All rights reserved.


#include "Libraries/DialogStringLibrary.h"

FString UDialogStringLibrary::FormatToCustomString(const FString& Input)
{
	FString Result;
	Result.Reserve(Input.Len());

	// #todo ... lower special characters like š, č, ...
	for (const TCHAR Character : Input)
	{
		if (!IsSpecialChar(Character) || IsTagCharacter(Character))
		{
			Result += FChar::ToLower(Character);
		}
	}

	return Result;
}

TArray<FString> UDialogStringLibrary::SplitToSentences(const FString& Input)
{
	TArray<FString> Result;

	FString Temp;
	Temp.Reserve(15);

	for (const TCHAR Character : Input)
	{
		if (IsSentenceSeparator(Character))
		{
			Result.Add(Temp);
			Temp.Reset(15);
		}
		else
		{
			Temp += Character;
		}
	}

	if (Temp.Len() > 0)
	{
		Result.Add(Temp);
	}

	return Result;
}

// TCHAR UDialogStringLibrary::ReplaceForLowerCase(const TCHAR Character) const
// {
// 	TMap<TCHAR, TCHAR> SpecialCharactersMap;
// 	SpecialCharactersMap.Add('Š', 'š');
// }
