// Copyright Epic Games, Inc. All Rights Reserved.

#include "Module/NaturalDialogSystem.h"
#include "ISettingsModule.h"
#include "ToolMenus.h"
#include "Module/NaturalDialogSystemSettings.h"


#define LOCTEXT_NAMESPACE "FNaturalDialogSystemModule"

void FNaturalDialogSystemModule::StartupModule()
{
	// This code will execute after your module is loaded into memory; the exact timing is specified in the .uplugin file per-module

	// Settings registration
	ModuleSettings = NewObject<UNaturalDialogSystemSettings>(GetTransientPackage(), "NaturalDialogSystemSettings", RF_Standalone);
	ModuleSettings->AddToRoot();

	// Register settings
	if (ISettingsModule* SettingsModule = FModuleManager::GetModulePtr<ISettingsModule>("Settings"))
	{
		SettingsModule->RegisterSettings("Project", "Plugins", "NaturalDialogSystem",
			LOCTEXT("RuntimeSettingsName", "Natural Dialog System"),
			LOCTEXT("RuntimeSettingsDescription", "Configure Natural Dialog System"),
			ModuleSettings);
	}
}

void FNaturalDialogSystemModule::ShutdownModule()
{
	// This function may be called during shutdown to clean up your module.  For modules that support dynamic reloading,
	// we call this function before unloading the module.

	if (ISettingsModule* SettingsModule = FModuleManager::GetModulePtr<ISettingsModule>("Settings"))
	{
		SettingsModule->UnregisterSettings("Project", "Plugins", "NaturalDialogSystem");
	}
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FNaturalDialogSystemModule, NaturalDialogSystem)
