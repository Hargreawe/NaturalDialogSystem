// Created by Michal Chamula. All rights reserved.


#include "Module/NaturalDialogSystemSettings.h"


#if WITH_EDITOR

void UNaturalDialogSystemSettings::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	UObject::PostEditChangeProperty(PropertyChangedEvent);

	SaveConfig(CPF_Config, *GetDefaultConfigFilename());
}

#endif
