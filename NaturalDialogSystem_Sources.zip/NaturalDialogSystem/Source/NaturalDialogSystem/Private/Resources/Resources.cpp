// Fill out your copyright notice in the Description page of Project Settings.


#include "Resources/Resources.h"

int FDictionaryData::NumOfWords = 1;

FNaturalDialogRow::FNaturalDialogRow()
{
	AnswerWave.Add(nullptr, nullptr);
}

FNaturalDialogRow_Base::FNaturalDialogRow_Base()
{
	AnswerWave.Add(nullptr, nullptr);
}
