// Created by Michal Chamula. All rights reserved.


#include "DefaultClasses/DefaultDictionaryPickerFunction.h"

#include "DefaultClasses/LevenshteinDistanceFunction.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetMathLibrary.h"
#include "Libraries/DialogStringLibrary.h"
#include "Resources/DictionaryRepresentation.h"

#define MAX_LEN_DIFF 5

DEFINE_LOG_CATEGORY(Log_DefaultDictPickerFunction);

void UDefaultDictionaryPickerFunction::InitializeWordPicker()
{
	Super::InitializeWordPicker();

	CachedDictionarySubsystem = Cast<UDictionarySubsystem>(GetOuter());
}

FString UDefaultDictionaryPickerFunction::PickWordFromDictionary(const FString& Input) const
{
	FString Result;
	const int32 InputLen = Input.Len();
	const UDictionarySubsystem* DictionarySubsystem = nullptr;

	// Cache dictionary subsystem which we use
	if (CachedDictionarySubsystem.IsValid())
	{
		DictionarySubsystem = CachedDictionarySubsystem.Get();
	}
	else
	{
		UGameInstance* GameInstance = UGameplayStatics::GetGameInstance(this);
		if (GameInstance)
		{
			DictionarySubsystem = GameInstance->GetSubsystem<UDictionarySubsystem>();
		}
	}

	// If is dict subsystem invalid, we don't allow words picking
	if (!DictionarySubsystem)
	{
		UE_LOG(Log_DefaultDictPickerFunction, Error, TEXT("Failed to retrieve dictionary subsystem"));
		return Result;
	}

	// Retrieve word from dict data
	if (InputLen > 0)
	{
		const UDictionaryRepresentation* DictionaryRepresentation = DictionarySubsystem->GetDictionary();
		if (ensure(DictionaryRepresentation && StringMetricDistanceFunctionInstance))
		{
			const FString NormalizedInput = UDialogStringLibrary::FormatToCustomString(Input);
			int32 MinEvaluation = MAX_int32;
			FString WordWithMinEvaluation;
			for (int32 SubstituteLen = 0; SubstituteLen < MAX_LEN_DIFF; SubstituteLen++)
			{
				// Find all words of len
				TArray<FString> Words = DictionaryRepresentation->GetListOfWordsOfLen(InputLen + SubstituteLen);
				if (SubstituteLen > 0)
				{
					Words.Append(DictionaryRepresentation->GetListOfWordsOfLen(InputLen - SubstituteLen));
				}

				TArray<int32> WordsEvaluation;
				WordsEvaluation.Reserve(Words.Num());

				for (const FString& Word : Words)
				{
					const int32 Evaluation = StringMetricDistanceFunctionInstance->GetStringDistance(Word, NormalizedInput);
					if (Evaluation == 0) // Correct word
					{
						return Word;
					}

					WordsEvaluation.Add(Evaluation);
				}

				// Save found word data
				int32 Index;
				int32 NewMinEval;
				UKismetMathLibrary::MinOfIntArray(WordsEvaluation, Index, NewMinEval);

				if (Index != INDEX_NONE && NewMinEval < MinEvaluation && NewMinEval < Words[Index].Len() - 1)
				{
					MinEvaluation = NewMinEval;
					WordWithMinEvaluation = Words[Index];
				}

				// Check stop criteria if word len is too different from input, we use this stop criteria 
				if (MinEvaluation <= SubstituteLen)
				{
					break;
				}
			}

			return WordWithMinEvaluation;
		}
	}
	else
	{
		UE_LOG(Log_DefaultDictPickerFunction, Warning, TEXT("Empty input text"));
	}

	return Result;
}
