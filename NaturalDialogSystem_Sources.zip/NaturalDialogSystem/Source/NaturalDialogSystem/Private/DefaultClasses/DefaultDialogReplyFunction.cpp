// Created by Michal Chamula. All rights reserved.


#include "DefaultClasses/DefaultDialogReplyFunction.h"
#include "Core/PlayerNaturalDialogComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetStringLibrary.h"
#include "Libraries/DialogStringLibrary.h"
#include "Resources/DictionaryRepresentation.h"


DEFINE_LOG_CATEGORY(Log_DefaultDialogReplyFunction);

void UDefaultDialogReplyFunction::InitializeDialogReplyPicker()
{
	Super::InitializeDialogReplyPicker();

	// Initialize all important references
	UGameInstance* GameInstance = UGameplayStatics::GetGameInstance(this);
	if (GameInstance)
	{
		DictionarySubsystem = GameInstance->GetSubsystem<UDictionarySubsystem>();
		if (DictionarySubsystem.IsValid())
		{
			DictionaryRepresentation = DictionarySubsystem.Get()->GetDictionary();
		}
	}

	OwnerComponent = Cast<UPlayerNaturalDialogComponent>(GetOuter());

	// Handle defaults table registration
	if (DefaultResponses)
	{
		HandleNewTableRegistration(DefaultResponses);
	}
	else
	{
		UE_LOG(Log_DefaultDialogReplyFunction, Warning, TEXT("Default responses table is invalid"));
	}

	if (ensure(OwnerComponent.IsValid()))
	{
		OwnerComponent.Get()->OnDataTableAdded.AddUniqueDynamic(this, &UDefaultDialogReplyFunction::HandleNewTableRegistration);
		OwnerComponent.Get()->OnDataTableRemoved.AddUniqueDynamic(this, &UDefaultDialogReplyFunction::HandleRegisteredTableRemoved);
	}
}

bool UDefaultDialogReplyFunction::GenerateReply(const TArray<FString>& Keywords, const UNpcNaturalDialogComponent* NpcNaturalDialogComponent, const UDataTable*& ResultTable, FName& ResultRowName)
{
	bool Result = false;

	ResultTable = nullptr;
	ResultRowName = FName();

	if (!DictionaryRepresentation.IsValid())
	{
		UE_LOG(Log_DefaultDialogReplyFunction, Error, TEXT("Invalid dictionary representation ptr value"));
		return Result;
	}

	if (Keywords.IsValidIndex(0))
	{
		TSet<const UDataTable*> TableSet;
		const FDictionaryData* InitialDictData = DictionaryRepresentation.Get()->GetWordData(Keywords[0]);

		// Set initial tables
		if (InitialDictData)
		{
			TableSet.Append(InitialDictData->GetTables());
		}
		else
		{
			UE_LOG(Log_DefaultDialogReplyFunction, Error, TEXT("Not valid dict data for word (%s)"), *Keywords[0]);
		}

		// Select only tables which have intersection with other keywords
		// #todo ... we can get zero set intersection, validate intersection with the most occurence of keywords
		for (const FString& Keyword : Keywords)
		{
			const FDictionaryData* DictionaryData = DictionaryRepresentation.Get()->GetWordData(Keyword);
			if (DictionaryData)
			{
				TableSet = TableSet.Intersect(DictionaryData->GetTables());
			}
			else
			{
				UE_LOG(Log_DefaultDialogReplyFunction, Error, TEXT("Not valid dict data for word (%s)"), *Keywords[0]);
			}
		}

		// Finally we make intersect on data tables, which NPC contains in component
		// By this, we remove unwanted tables
		if (OwnerComponent.IsValid())
		{
			TableSet = TableSet.Intersect(OwnerComponent.Get()->GetDialogTables_Const(NpcNaturalDialogComponent));
		}

#if !UE_BUILD_SHIPPING

		FString DebugMessage = TEXT("Selected tables for reply: { ");
		DebugMessage.Reserve(100);

		for (const UDataTable* Table : TableSet)
		{
			DebugMessage += Table->GetName() + " ";
		}

		DebugMessage += "}";
		UE_LOG(Log_DefaultDialogReplyFunction, Log, TEXT("%s"), *DebugMessage);

#endif

		// Now we check only selected tables
		if (TableSet.Num() > 0)
		{
			TArray<FReplyData> ReplyData;
			ReplyData.Reserve(TableSet.Num());

			for (const UDataTable* OutTable : TableSet)
			{
				// Find row with most keyword match
				OutTable->ForeachRow<FNaturalDialogRow>("Searching for data from keywords", [&ReplyData, OutTable, &Keywords](const FName& Key, const FNaturalDialogRow& Value)
				{
					int32 MatchCount = 0;

					// Normalize words from row, then check if contains the word in keywords
					// #todo ... this normalization is now runtime, we could optimize this, using cached normalization for all documents after game start, but the memory complexity is O(n^2) instead of O(n) where n is complexity of one document
					TArray<FString> AskWords = UKismetStringLibrary::ParseIntoArray(Value.Ask.ToString(), TEXT(" "), true);

					for (int32 i = 0; i < AskWords.Num(); i++)
					{
						const FString& NormalizedAskWord = UDialogStringLibrary::FormatToCustomString(AskWords[i]);
						if (Keywords.Contains(NormalizedAskWord))
						{
							MatchCount++;
						}
					}

					const FReplyData TempData = FReplyData(MatchCount, OutTable, Key);
					const int32 DataIndex = ReplyData.Find(TempData);

					// If any reply data with the same data table contains reply with equals num of keywords, then add this data asn new possibility to response, from these data we select with the hightest metric value
					if (MatchCount > 0 && (DataIndex == INDEX_NONE || ReplyData[DataIndex].NumOfMatchedKeywords == TempData.NumOfMatchedKeywords))
					{
						ReplyData.Add(TempData);
					}
					else if (DataIndex != INDEX_NONE && ReplyData[DataIndex].NumOfMatchedKeywords < TempData.NumOfMatchedKeywords)
					{
						ReplyData[DataIndex] = TempData;
					}
				});
			}

			// Find all elements with highness value
			const FReplyData BestReplyData = FindBestReply(ReplyData);

			// We need at least 3 matched keywords to select correct response, or if keywords are matched, because we can say only "hi"
			if (BestReplyData.NumOfMatchedKeywords >= MIN_KEYWORDS_COUNT || BestReplyData.NumOfMatchedKeywords == Keywords.Num())
			{
				ResultTable = BestReplyData.InTable;
				ResultRowName = BestReplyData.RowName;
				Result = true;

				// Decrease metric value
				ModifyMetricValue(ResultTable, ResultRowName);
			}
		}
	}
	else
	{
		UE_LOG(Log_DefaultDialogReplyFunction, Warning, TEXT("Empty keywords input array"));
	}

	// DEFAULT REPLIES
	// Implement default reply
	// Used if no reply was found for player input
	if (ResultTable == nullptr && DefaultResponses)
	{
		// Fill table data
		TArray<FReplyData> ReplyData;
		DefaultResponses->ForeachRow<FNaturalDialogRow_Base>("Searching for data from keywords", [&ReplyData, this](const FName& Key, const FNaturalDialogRow_Base& Value)
		{
			ReplyData.Add(FReplyData(0, DefaultResponses, Key));
		});

		if (ReplyData.IsValidIndex(0))
		{
			// Find the best, by using metric
			const FReplyData BestReplyData = FindBestReply(ReplyData);

			ResultTable = BestReplyData.InTable;
			ResultRowName = BestReplyData.RowName;

			// Decrease metric value
			ModifyMetricValue(ResultTable, ResultRowName);
		}
	}

	return Result;
}

void UDefaultDialogReplyFunction::Tick(float DeltaTime)
{
	// #todo ... manipulate with metric data trough time
}

TStatId UDefaultDialogReplyFunction::GetStatId() const
{
	RETURN_QUICK_DECLARE_CYCLE_STAT(UDefaultDialogReplyFunction, STATGROUP_Tickables);
}

void UDefaultDialogReplyFunction::HandleNewTableRegistration(const UDataTable* NewTable)
{
	if (NewTable)
	{
		TMap<FName, float>& StoredValue = Metric.Add(NewTable, TMap<FName, float>());

		if (NewTable->GetRowStruct()->IsChildOf(FNaturalDialogRow::StaticStruct()))
		{
			// Other, user defined, tables
			NewTable->ForeachRow<FNaturalDialogRow>("Creating metrics values", [&StoredValue](const FName& Key, const FNaturalDialogRow& Value)
			{
				StoredValue.Add(Key, 1.f);
			});
		}
		else if (NewTable->GetRowStruct()->IsChildOf(FNaturalDialogRow_Base::StaticStruct()))
		{
			// FNaturalDialogRow_Base for now appears only one time, for default response values
			NewTable->ForeachRow<FNaturalDialogRow_Base>("Creating metrics values", [&StoredValue](const FName& Key, const FNaturalDialogRow_Base& Value)
			{
				StoredValue.Add(Key, 1.f);
			});
		}

		UE_LOG(Log_DefaultDialogReplyFunction, Log, TEXT("Creating metric values for table %s"), *NewTable->GetName());
	}
}

void UDefaultDialogReplyFunction::HandleRegisteredTableRemoved(const UDataTable* NewTable)
{
	Metric.Remove(NewTable);
	UE_LOG(Log_DefaultDialogReplyFunction, Log, TEXT("Removing metric values for table %s"), *NewTable->GetName());
}

FReplyData UDefaultDialogReplyFunction::FindBestReply(const TArray<FReplyData>& AllReplies) const
{
	FReplyData Result;

	if (AllReplies.IsValidIndex(0))
	{
		// Find all elements with highness value
		TArray<int32> ElementIndexes;
		int32 MaxValue = INDEX_NONE;
		for (int32 i = 0; i < AllReplies.Num(); i++)
		{
			const int32 NewMaxValue = AllReplies[i].NumOfMatchedKeywords;

			if (NewMaxValue == MaxValue)
			{
				ElementIndexes.Add(i);
			}
			else if (NewMaxValue > MaxValue)
			{
				MaxValue = NewMaxValue;
				ElementIndexes.Reset(5);
				ElementIndexes.Add(i);
			}
		}

		// Now from all max values we choose one with best metric value
		const FReplyData* BestResultData = &AllReplies[0];

		for (int32 i = 1; i < ElementIndexes.Num(); i++)
		{
			const FDialogMetricRow* BestRow = Metric.Find(BestResultData->InTable);
			const FDialogMetricRow* CurrentRow = Metric.Find(AllReplies[i].InTable);
			if (ensure(BestRow && CurrentRow))
			{
				const float* BestValue = BestRow->Find(BestResultData->RowName);
				const float* CurrentValue = CurrentRow->Find(AllReplies[i].RowName);
				if (*BestValue < *CurrentValue)
				{
					BestResultData = &AllReplies[i];
				}
			}
		}

		Result = *BestResultData;
	}

	return Result;
}

void UDefaultDialogReplyFunction::ModifyMetricValue(const UDataTable* InTable, const FName InRow)
{
	if (InTable)
	{
		FDialogMetricRow* MetricData = Metric.Find(InTable);
		if (MetricData)
		{
			float* MetricValue = MetricData->Find(InRow);
			if (MetricCurve)
			{
				// Curve metric calculation
				const float NewValue = MetricCurve->GetFloatValue(*MetricValue);
				UE_LOG(Log_DefaultDialogReplyFunction, Log, TEXT("Metric has changed (%s | %s), (old value = %f, new value = %f)"), *InTable->GetName(), *InRow.ToString(), *MetricValue, NewValue);
				*MetricValue = NewValue;
			}
			else
			{
				// Default metric calculation
				const float NewValue = FMath::Clamp(*MetricValue * 0.5f, 0.01f, 1.f);
				UE_LOG(Log_DefaultDialogReplyFunction, Log, TEXT("Metric has changed (%s | %s), (old value = %f, new value = %f)"), *InTable->GetName(), *InRow.ToString(), *MetricValue, NewValue);
				*MetricValue = NewValue;

				UE_LOG(Log_DefaultDialogReplyFunction, Warning, TEXT("Curve isn ont set, for metric calculation"));
			}

			// Log metric values into log
			// Slow operation, but perfect for debugging
			LogMetricValues();
		}
		else
		{
			UE_LOG(Log_DefaultDialogReplyFunction, Error, TEXT("Metric doesn't contain data table data (%s)"), *InTable->GetName());
		}
	}
	else
	{
		UE_LOG(Log_DefaultDialogReplyFunction, Error, TEXT("Input table is not valid in function ModifyMetricValue()"));
	}
}

void UDefaultDialogReplyFunction::LogMetricValues()
{
	// #todo ... finish this

#if !UE_BUILD_SHIPPING

	// static FString Rows = TEXT("   Rows > ");
	// static FString Columns = TEXT("V Tables ");
	// static FString VertSeparator = TEXT("||");
	// static FString HorizSeparator = TEXT("=");
	//
	// TArray<int32> TablesLens;
	// for (const TPair<const UDataTable*, FDialogMetricRow>& Table : Metric)
	// {
	// 	TablesLens.Add(Table.Value.Num());
	// }
	//
	// int32 TempIndex;
	// const int32 NumOfColumns = FMath::Max(TablesLens, &TempIndex);
	// const int32 Abc = FString::FromInt(NumOfColumns).Len();
	//
	// FString Result = "Metric values\n" + Rows + VertSeparator + "\n"; // First line
	// Result.Append(Columns + VertSeparator);                           // Second line
	//
	// for (int32 i = 0; i < NumOfColumns; i++)
	// {
	// 	Result.Append(" Row " + FString::FromInt(i + 1) + " ");
	// }

#endif
}
