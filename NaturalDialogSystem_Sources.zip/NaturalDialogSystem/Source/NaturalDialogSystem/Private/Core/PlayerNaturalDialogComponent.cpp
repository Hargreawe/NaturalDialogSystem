// Created by Michal Chamula. All rights reserved.


#include "Core/PlayerNaturalDialogComponent.h"
#include "Core/NpcNaturalDialogComponent.h"
#include "DefaultClasses/DefaultDialogReplyFunction.h"
#include "Engine/ActorChannel.h"
#include "Libraries/DialogStringLibrary.h"
#include "Net/UnrealNetwork.h"

#define DEFAULT_REPLY NSLOCTEXT("Natural Dialog System", "Default Reply", "I don't understand you");

FDialogTableHierarchy::FDialogTableHierarchy(const UNpcNaturalDialogComponent* NpcNaturalDialogComponent)
	: OwnerNpcNaturalDialogComponent(NpcNaturalDialogComponent)
{
	if (NpcNaturalDialogComponent)
	{
		DialogTables.Reserve(NpcNaturalDialogComponent->GetInitialDialogTables().Num());

		for (UDataTable* DataTable : NpcNaturalDialogComponent->GetInitialDialogTables())
		{
			DialogTables.Add(DataTable);
		}
	}
}


DEFINE_LOG_CATEGORY(LogPlayerNaturalDialogComponent);

UPlayerNaturalDialogComponent::UPlayerNaturalDialogComponent()
{
	PrimaryComponentTick.bCanEverTick = false;

	SetIsReplicatedByDefault(true);
	ReplyFunctionClass = UDefaultDialogReplyFunction::StaticClass();
}

void UPlayerNaturalDialogComponent::BeginPlay()
{
	Super::BeginPlay();

	// Cache dictionary subsystem
	if (GetOwner() && GetOwner()->GetGameInstance())
	{
		DictSubsystem = GetOwner()->GetGameInstance()->GetSubsystem<UDictionarySubsystem>();
	}

	// Dialog reply function object instance construction
	CreateReplyObjectInstance(ReplyFunctionClass);
}

bool UPlayerNaturalDialogComponent::ReplicateSubobjects(UActorChannel* Channel, FOutBunch* Bunch, FReplicationFlags* RepFlags)
{
	bool Result = Super::ReplicateSubobjects(Channel, Bunch, RepFlags);
	Result |= Channel->ReplicateSubobjectList(ActiveExecutionTasks, *Bunch, *RepFlags);

	return Result;
}

void UPlayerNaturalDialogComponent::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	// Other clients doesn't need know about data of another player
	DOREPLIFETIME_CONDITION(UPlayerNaturalDialogComponent, DialogData, COND_OwnerOnly);
	DOREPLIFETIME_CONDITION(UPlayerNaturalDialogComponent, ActiveExecutionTasks, COND_OwnerOnly);
}

void UPlayerNaturalDialogComponent::CreateReplyObjectInstance(const TSubclassOf<UDialogReplyFunction> InReplyFunctionClass)
{
	const TSubclassOf<UDialogReplyFunction> UsedReplyFunctionClass = InReplyFunctionClass ? InReplyFunctionClass : UDefaultDialogReplyFunction::StaticClass();

#if !UE_BUILD_SHIPPING

	if (InReplyFunctionClass)
	{
		UE_LOG(LogPlayerNaturalDialogComponent, Log, TEXT("%s used for reply function"), *InReplyFunctionClass->GetClass()->GetName());
	}
	else
	{
		UE_LOG(LogPlayerNaturalDialogComponent, Warning, TEXT("%s used for reply function as default"), *UDefaultDialogReplyFunction::StaticClass()->GetClass()->GetName());
	}

#endif

	// Create reply function
	ReplyFunctionInstance = NewObject<UDialogReplyFunction>(this, UsedReplyFunctionClass);
	ReplyFunctionInstance->InitializeDialogReplyPicker();

	// Check override of abstract method 
	const UDataTable* ResultTable;
	FName RowName;
	ReplyFunctionInstance->GenerateReply(TArray<FString>(), nullptr, ResultTable, RowName);
}

FString UPlayerNaturalDialogComponent::GenerateDialogReply(const FText& Input, const UNpcNaturalDialogComponent* NpcNaturalDialogComponent)
{
	const FText InvalidAnswer = DEFAULT_REPLY;
	FString Result = InvalidAnswer.ToString();

	if (DictSubsystem.IsValid() && ensure(GetOwnerPlayerController()))
	{
		// Validate function instance, if is not valid yet, we create new one
		if (!ReplyFunctionInstance)
		{
			UE_LOG(LogPlayerNaturalDialogComponent, Warning, TEXT("Reply instance is not valid yet, creating new one"));
			CreateReplyObjectInstance(ReplyFunctionClass);
		}

		// Validate if we already met the NPC character, if not, then initialize startup tables
		if (!DialogData.Contains(NpcNaturalDialogComponent) && NpcNaturalDialogComponent->HasInitialDialogTables())
		{
			for (UDataTable* InitTable : NpcNaturalDialogComponent->GetInitialDialogTables())
			{
				if (InitTable)
				{
					RegisterDialogData(NpcNaturalDialogComponent, InitTable);
					break;
				}
			}
		}

		const TArray<FString> SplitInput = UDialogStringLibrary::SplitToSentences(Input.ToString());
		Result.Empty();

		for (const FString& Sentence : SplitInput)
		{
			// Keywords we are searching for
			const TArray<FString> Keywords = DictSubsystem.Get()->GenerateKeywords(Sentence);

#if !UE_BUILD_SHIPPING

			FString StringDebugKeywords = "";
			StringDebugKeywords.Reserve(Keywords.Num() * 10);
			for (const FString& Keyword : Keywords)
			{
				StringDebugKeywords += Keyword + TEXT(" ");
			}
			UE_LOG(LogPlayerNaturalDialogComponent, Log, TEXT("Founds keywords are: %s"), *StringDebugKeywords);

#endif

			const UDataTable* ResultTable;
			FName RowName;

			// If the correct answer is not found, then override the result and end generating reply
			const bool bWasReplyFound = ReplyFunctionInstance->GenerateReply(Keywords, NpcNaturalDialogComponent, ResultTable, RowName);

			TSoftObjectPtr<UDialogueWave>* SoundObj = nullptr; // Sound to play in dialog

			if (ResultTable && !RowName.IsNone())
			{
				FNaturalDialogRow* Row = nullptr;
				FNaturalDialogRow_Base* RowBase = nullptr;

				if (ResultTable->GetRowStruct()->IsChildOf(FNaturalDialogRow::StaticStruct()))
				{
					Row = ResultTable->FindRow<FNaturalDialogRow>(RowName, nullptr);
				}
				else
				{
					RowBase = ResultTable->FindRow<FNaturalDialogRow_Base>(RowName, nullptr);
				}

				if (Row)
				{
					// If the answer has execution tasks we fire them
					if (Row->DialogTasks.IsValidIndex(0))
					{
						for (TSoftClassPtr<UNaturalDialogTask> Task : Row->DialogTasks)
						{
							const TSubclassOf<UNaturalDialogTask> LoadedClass(Task.LoadSynchronous());
							Server_ExecuteDialogTask(NpcNaturalDialogComponent, LoadedClass);
						}
					}

					// Cache sound data into variable
					if ((GetOuter()))
					{
						SoundObj = Row->AnswerWave.Find(GetOuter()->GetClass());
					}

					Result.Append(Row->Answer.ToString() + TEXT(" "));
				}
				else if (RowBase)
				{
					// Cache sound data into variable
					if ((GetOuter()))
					{
						SoundObj = RowBase->AnswerWave.Find(GetOuter()->GetClass());
					}

					Result = RowBase->Answer.ToString() + TEXT(" ");
				}
			}

			if (SoundObj)
			{
				UDialogueWave* LoadedSoundWave = SoundObj->LoadSynchronous();
				if (LoadedSoundWave)
				{
					// #todo ... play dialog voice
				}
			}

			if (!bWasReplyFound)
			{
				return Result;
			}
		}
	}

	return Result;
}

void UPlayerNaturalDialogComponent::RegisterDialogData(const UNpcNaturalDialogComponent* NpcNaturalDialogComponent, UDataTable* DialogTable)
{
	if (DialogTable && DialogTable->GetRowStruct()->IsChildOf(FNaturalDialogRow::StaticStruct()))
	{
		// Do not invert these steps, if we set first server then client, we can override potential replication from server step

		// Step 1. -> Set dialog data for client
		if (!GetOwner()->HasAuthority())
		{
			RegisterDialogTable_Internal(NpcNaturalDialogComponent, DialogTable);
		}

		// Step 2. -> Set dialog data on server, then we can wait for data replication.
		Server_RegisterDialogData(NpcNaturalDialogComponent, DialogTable);
	}
	else
	{
		UE_LOG(LogPlayerNaturalDialogComponent, Error, TEXT("Not valid dialog table i"));
	}
}

void UPlayerNaturalDialogComponent::UnregisterDialogData(const UNpcNaturalDialogComponent* NpcNaturalDialogComponent, UDataTable* DialogTable)
{
	// Step 1. -> Set dialog data for client
	if (!GetOwner()->HasAuthority())
	{
		UnregisterDialogTable_Internal(NpcNaturalDialogComponent, DialogTable);
	}

	// Step 2. -> Set dialog data on server, then we can wait for data replication.
	Server_UnregisterDialogData(NpcNaturalDialogComponent, DialogTable);
}

TSet<UDataTable*> UPlayerNaturalDialogComponent::GetDialogTables(const UNpcNaturalDialogComponent* NpcNaturalDialogComponent) const
{
	TSet<UDataTable*> Result;

	if (NpcNaturalDialogComponent)
	{
		const int32 Index = DialogData.Find(NpcNaturalDialogComponent);
		if (DialogData.IsValidIndex(Index))
		{
			Result = TSet<UDataTable*>(DialogData[Index].DialogTables);
		}
	}

	return Result;
}

TSet<const UDataTable*> UPlayerNaturalDialogComponent::GetDialogTables_Const(const UNpcNaturalDialogComponent* NpcNaturalDialogComponent) const
{
	TSet<const UDataTable*> Result;

	if (NpcNaturalDialogComponent)
	{
		const int32 Index = DialogData.Find(NpcNaturalDialogComponent);
		if (DialogData.IsValidIndex(Index))
		{
			Result.Reserve(DialogData[Index].DialogTables.Num());

			for (const UDataTable* Table : DialogData[Index].DialogTables)
			{
				Result.Add(Table);
			}
		}
	}

	return Result;
}

void UPlayerNaturalDialogComponent::Server_RegisterDialogData_Implementation(const UNpcNaturalDialogComponent* NpcNaturalDialogComponent, UDataTable* DialogTable)
{
	if (NpcNaturalDialogComponent && DialogTable && DialogTable->GetRowStruct()->IsChildOf(FNaturalDialogRow::StaticStruct()))
	{
		RegisterDialogTable_Internal(NpcNaturalDialogComponent, DialogTable);
	}
	else
	{
		UE_LOG(LogPlayerNaturalDialogComponent, Warning, TEXT("Trying to register invalid data asset or data asset with invalid row structure"));
	}
}

bool UPlayerNaturalDialogComponent::Server_RegisterDialogData_Validate(const UNpcNaturalDialogComponent* NpcNaturalDialogComponent, UDataTable* DialogTable)
{
	return true;
}

void UPlayerNaturalDialogComponent::Server_UnregisterDialogData_Implementation(const UNpcNaturalDialogComponent* NpcNaturalDialogComponent, UDataTable* DialogTable)
{
	UnregisterDialogTable_Internal(NpcNaturalDialogComponent, DialogTable);
}

bool UPlayerNaturalDialogComponent::Server_UnregisterDialogData_Validate(const UNpcNaturalDialogComponent* NpcNaturalDialogComponent, UDataTable* DialogTable)
{
	return true;
}


void UPlayerNaturalDialogComponent::Server_ExecuteDialogTask_Implementation(const UNpcNaturalDialogComponent* NpcNaturalDialogComponent, TSubclassOf<UNaturalDialogTask> Task)
{
	if (!NpcNaturalDialogComponent)
	{
		UE_LOG(LogPlayerNaturalDialogComponent, Error, TEXT("Input NPC component object is invalid"));
		return;
	}

	if (!Task)
	{
		UE_LOG(LogPlayerNaturalDialogComponent, Error, TEXT("Task object is invalid"));
		return;
	}
	APlayerController* Controller = GetOwnerPlayerController();
	if (!Controller)
	{
		UE_LOG(LogPlayerNaturalDialogComponent, Error, TEXT("Invalid player controller for task execution"));
		return;
	}

#if !UE_BUILD_SHIPPING

	const TCHAR* TaskName = *Task->GetClass()->GetName();
	if (GetOwner())
	{
		UE_LOG(LogPlayerNaturalDialogComponent, Log, TEXT("New task %s start execution for owner actor %s"), TaskName, *GetOwner()->GetClass()->GetName());
	}
	else
	{
		UE_LOG(LogPlayerNaturalDialogComponent, Log, TEXT("New task object %s start execution"), TaskName);
	}

#endif

	UNaturalDialogTask* TaskInstance = NewObject<UNaturalDialogTask>(this, Task);
	TaskInstance->bHasAuthority = true;

	ActiveExecutionTasks.Add(TaskInstance);
	TaskInstance->ExecuteTask(Controller, NpcNaturalDialogComponent->GetOwner());
}

bool UPlayerNaturalDialogComponent::Server_ExecuteDialogTask_Validate(const UNpcNaturalDialogComponent* NpcNaturalDialogComponent, TSubclassOf<UNaturalDialogTask> Task)
{
	return true;
}

void UPlayerNaturalDialogComponent::Server_FinishDialogTaskExecution_Implementation(UNaturalDialogTask* Task)
{
	if (!Task)
	{
		UE_LOG(LogPlayerNaturalDialogComponent, Error, TEXT("Input param Task is invalid for finalize task object"));
		return;
	}

#if !UE_BUILD_SHIPPING

	const TCHAR* TaskName = *Task->GetClass()->GetName();
	if (GetOwner())
	{
		UE_LOG(LogPlayerNaturalDialogComponent, Log, TEXT("Task object %s was sucessfully executed for owner actor %s"), TaskName, *GetOwner()->GetClass()->GetName());
	}
	else
	{
		UE_LOG(LogPlayerNaturalDialogComponent, Log, TEXT("Task object %s was sucessfully executed"), TaskName);
	}

#endif

	ActiveExecutionTasks.Remove(Task); // Finish task
}

bool UPlayerNaturalDialogComponent::Server_FinishDialogTaskExecution_Validate(UNaturalDialogTask* Task)
{
	return true;
}

void UPlayerNaturalDialogComponent::OnRep_ActiveExecutionTasks()
{
	for (UNaturalDialogTask* Task : ActiveExecutionTasks)
	{
		// Validate if the task has not already started
		if (!Task->bHasStarted)
		{
			// Player and NPC data should be set from server execution
			// We need only execute the task on client site
			Task->StartTaskExecution_Internal();
		}
	}
}

void UPlayerNaturalDialogComponent::RegisterDialogTable_Internal(const UNpcNaturalDialogComponent* NpcNaturalDialogComponent, UDataTable* DialogTable)
{
	if (NpcNaturalDialogComponent && DialogTable)
	{
		// First we initialize array element, with initial tables of NpcNaturalDialogComponent
		if (!DialogData.Contains(NpcNaturalDialogComponent))
		{
			DialogData.Add(NpcNaturalDialogComponent);
			for (const UDataTable* InitTable : NpcNaturalDialogComponent->GetInitialDialogTables())
			{
				OnDataTableAdded.Broadcast(InitTable);
			}
			UE_LOG(LogPlayerNaturalDialogComponent, Log, TEXT("New npc (%s) registered in PlayerNaturalDialogComponent(%s)"), *NpcNaturalDialogComponent->GetOwner()->GetName());
		}

		// Now we check if table already exists in dialog data of NPC
		const int32 ElementIndex = DialogData.Find(NpcNaturalDialogComponent);
		TArray<UDataTable*>& Data = DialogData[ElementIndex].DialogTables;

		if (!Data.Contains(DialogTable))
		{
			UE_LOG(LogPlayerNaturalDialogComponent, Log, TEXT("New data asset registered (%s)"), *DialogTable->GetName());

			Data.Add(DialogTable);
			OnDataTableAdded.Broadcast(DialogTable);
		}
		else
		{
			UE_LOG(LogPlayerNaturalDialogComponent, Log, TEXT("Trying to add new data asset, but already exists in dialog component"));
		}
	}
	else
	{
		UE_LOG(LogPlayerNaturalDialogComponent, Error, TEXT("Invalid input params in function RegisterDialogTable_Internal()"));
	}
}

void UPlayerNaturalDialogComponent::UnregisterDialogTable_Internal(const UNpcNaturalDialogComponent* NpcNaturalDialogComponent, UDataTable* DialogTable)
{
	if (NpcNaturalDialogComponent && DialogTable)
	{
		const int32 Index = DialogData.Find(NpcNaturalDialogComponent);

		if (DialogData.IsValidIndex(Index))
		{
			UE_LOG(LogPlayerNaturalDialogComponent, Log, TEXT("Removing dialog table (%s)"), *DialogTable->GetName());

			DialogData[Index].DialogTables.Remove(DialogTable);
			OnDataTableRemoved.Broadcast(DialogTable);
		}
		else
		{
			UE_LOG(LogPlayerNaturalDialogComponent, Warning, TEXT("Component doesn't contain dialog table (%s) for Npc dialog component"), *DialogTable->GetName());
		}
	}
	else
	{
		UE_LOG(LogPlayerNaturalDialogComponent, Error, TEXT("Invalid input params in function UnregisterDialogTable_Internal()"));
	}
}

APlayerController* UPlayerNaturalDialogComponent::GetOwnerPlayerController() const
{
	APlayerController* Result = nullptr;

	APawn* OwnerPawn = Cast<APawn>(GetOwner());
	if (OwnerPawn)
	{
		Result = Cast<APlayerController>(OwnerPawn->GetController());
	}

#if !UE_BUILD_SHIPPING

	// Validate player controller
	if (!Result)
	{
		UE_LOG(LogPlayerNaturalDialogComponent, Error, TEXT("Player natural dialog component is attached in player not controlled pawn (%s), all requests for replies will be drop"), *GetOwner()->GetClass()->GetName());
	}

#endif

	return Result;
}
