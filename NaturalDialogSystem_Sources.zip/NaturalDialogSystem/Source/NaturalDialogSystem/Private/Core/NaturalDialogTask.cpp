﻿// Created by Michal Chamula. All rights reserved.


#include "Core/NaturalDialogTask.h"

#include "Core/NpcNaturalDialogComponent.h"
#include "Core/PlayerNaturalDialogComponent.h"
#include "Engine/NetDriver.h"
#include "Net/UnrealNetwork.h"

DEFINE_LOG_CATEGORY(LogNaturalDialogTask);

FDialogTaskPlayerData::FDialogTaskPlayerData(APlayerController* InPlayerController)
	: PlayerPawn(nullptr), NaturalDialogSystemComponent(nullptr), PlayerController(InPlayerController), PlayerState(nullptr)
{
	{
		if (InPlayerController)
		{
			PlayerPawn = InPlayerController->GetPawn();
			PlayerState = InPlayerController->PlayerState;
		}

		if (PlayerPawn)
		{
			NaturalDialogSystemComponent = PlayerPawn->FindComponentByClass<UPlayerNaturalDialogComponent>();
		}
	}
}

FDialogTaskNPCData::FDialogTaskNPCData(AActor* InOwningActor)
	: OwningActor(InOwningActor)
{
	{
		if (InOwningActor)
		{
			NaturalDialogSystemComponent = InOwningActor->FindComponentByClass<UNpcNaturalDialogComponent>();
		}
	}
}

UNaturalDialogTask::UNaturalDialogTask()
{
	bHasStarted = false;
	bHasAuthority = false;
	bPendingFinish = false;
}

void UNaturalDialogTask::FinishTaskExecution()
{
	// // We do one more check if task is pending finish or not, because we dont want to send unnecessarily request on server 
	// if (!bPendingFinish)
	// {
	// 	// Step 1. -> We finish task locally
	// 	FinishTaskExecution_Internal();
	//
	// 	// Step 2. -> If is local Pc client, we sent request on server to kill task
	// 	if (!HasAuthority())
	// 	{
	// 		Server_FinishTask();
	// 	}
	// }

	FinishTaskExecution_Internal();
}

UWorld* UNaturalDialogTask::GetWorld() const
{
	if (HasAllFlags(RF_ClassDefaultObject))
	{
		// If we are a CDO, we must return nullptr instead of calling Outer->GetWorld() to fool UObject::ImplementsGetWorld.
		return nullptr;
	}
	return GetOuter()->GetWorld();
}

int32 UNaturalDialogTask::GetFunctionCallspace(UFunction* Function, FFrame* Stack)
{
	if (HasAnyFlags(RF_ClassDefaultObject) || !IsSupportedForNetworking())
	{
		// This handles absorbing authority/cosmetic
		return GEngine->GetGlobalFunctionCallspace(Function, this, Stack);
	}
	check(GetOuter() != nullptr);
	return GetOuter()->GetFunctionCallspace(Function, Stack);
}

bool UNaturalDialogTask::CallRemoteFunction(UFunction* Function, void* Parameters, FOutParmRec* OutParams, FFrame* Stack)
{
	check(!HasAnyFlags(RF_ClassDefaultObject));
	check(GetOuter() != nullptr);

	AActor* Owner = CastChecked<AActor>(GetOuter());

	bool bProcessed = false;

	FWorldContext* const Context = GEngine->GetWorldContextFromWorld(GetWorld());
	if (Context != nullptr)
	{
		for (const FNamedNetDriver& Driver : Context->ActiveNetDrivers)
		{
			if (Driver.NetDriver != nullptr && Driver.NetDriver->ShouldReplicateFunction(Owner, Function))
			{
				Driver.NetDriver->ProcessRemoteFunction(Owner, Function, Parameters, OutParams, Stack, this);
				bProcessed = true;
			}
		}
	}

	return bProcessed;
}

void UNaturalDialogTask::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	UObject::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(UNaturalDialogTask, CachedPlayerData);
	DOREPLIFETIME(UNaturalDialogTask, CachedNPCData);
}

void UNaturalDialogTask::ExecuteTask(APlayerController* AskingPlayer, AActor* OwningActor)
{
	InitializeTaskData_Internal(AskingPlayer, OwningActor);

	if (IsTaskValid())
	{
		UE_LOG(LogNaturalDialogTask, Log, TEXT("Task references are valid, starting task execution"))
	}
	else
	{
		UE_LOG(LogNaturalDialogTask, Log, TEXT("Not all task references are valid, starting task execution without valid external values"));
	}

	StartTaskExecution_Internal();
}

void UNaturalDialogTask::StartTaskExecution_Internal()
{
	if (!bHasStarted)
	{
		bHasStarted = true;
		ReceiveOnTaskExecuted(CachedPlayerData, CachedNPCData);
	}
	else
	{
		UE_LOG(LogNaturalDialogTask, Warning, TEXT("Dialog task already executed"));
		// Has to be here return, because if we create and override child function, it has to stop here and do not execute other functionality
		return;
	}
}

void UNaturalDialogTask::FinishTaskExecution_Internal()
{
	if (!bPendingFinish)
	{
		bPendingFinish = true;
		ReceiveOnTaskFinished();

		APawn* Outer = Cast<APawn>(GetOuter());
		if (ensure(Outer))
		{
			UPlayerNaturalDialogComponent* Component = Outer->FindComponentByClass<UPlayerNaturalDialogComponent>();
			if (ensure(Component))
			{
				Component->Server_FinishDialogTaskExecution(this);
			}
		}
	}
}

void UNaturalDialogTask::InitializeTaskData_Internal(APlayerController* AskingPlayer, AActor* OwningActor)
{
	CachedPlayerData = FDialogTaskPlayerData(AskingPlayer);
	CachedNPCData = FDialogTaskNPCData(OwningActor);

	if (!CachedPlayerData.IsValid())
	{
		UE_LOG(LogNaturalDialogTask, Error, TEXT("Player data are not valid, plase check if you are using valid player controller when asking for reply in NaturalDialogComponent class"));
	}

	if (!CachedNPCData.IsValid())
	{
		UE_LOG(LogNaturalDialogTask, Error, TEXT("NPC data are not valid, plase check if component owner actorcontains NaturalDialogComponent class"));
	}
}

void UNaturalDialogTask::Server_FinishTask_Implementation()
{
	FinishTaskExecution_Internal();
}

bool UNaturalDialogTask::Server_FinishTask_Validate()
{
	return true;
}
