﻿// Created by Michal Chamula. All rights reserved.

#pragma once

#include "CoreMinimal.h"

#include "GameFramework/PlayerController.h"
#include "UObject/Object.h"
#include "NaturalDialogTask.generated.h"

class UPlayerNaturalDialogComponent;
class UNpcNaturalDialogComponent;

/**
 * Struct contains data about player character data
 * Used as param in dialog task, there are stored important references for function ExecuteTask()
 * Can be get from NaturalDialogTask object using function GetPlayerData()
 */
USTRUCT(BlueprintType)
struct FDialogTaskPlayerData
{
	GENERATED_BODY()

	FDialogTaskPlayerData()
		: PlayerPawn(nullptr), NaturalDialogSystemComponent(nullptr), PlayerController(nullptr), PlayerState(nullptr) {}

	explicit FDialogTaskPlayerData(APlayerController* InPlayerController);

	/** Reference to the player character, which is asking for reply */
	UPROPERTY(BlueprintReadOnly)
	APawn* PlayerPawn;

	/** Reference to the player natural dialog component, which is asking for reply */
	UPROPERTY(BlueprintReadOnly)
	UPlayerNaturalDialogComponent* NaturalDialogSystemComponent;

	/** Reference to the player controller, which is asking for reply */
	UPROPERTY(BlueprintReadOnly)
	APlayerController* PlayerController;

	/** Reference to the player state, which is asking for reply */
	UPROPERTY(BlueprintReadOnly)
	APlayerState* PlayerState;

	__forceinline bool IsValid() const { return PlayerPawn && PlayerController && PlayerState; }
};

/**
 * Struct contains data about task owner character
 * Used as param in dialog task, there are stored important references for function ExecuteTask()
 * Can be get from NaturalDialogTask object using function GetNPCData()
 */
USTRUCT(BlueprintType)
struct FDialogTaskNPCData
{
	GENERATED_BODY()

	FDialogTaskNPCData()
		: OwningActor(nullptr), NaturalDialogSystemComponent(nullptr) {}

	explicit FDialogTaskNPCData(AActor* InOwningActor);

	/** Reference to the task creator */
	UPROPERTY(BlueprintReadOnly)
	AActor* OwningActor;

	/** Reference to the task component, where task was created from */
	UPROPERTY(BlueprintReadOnly)
	UNpcNaturalDialogComponent* NaturalDialogSystemComponent;

	__forceinline bool IsValid() const { return OwningActor && NaturalDialogSystemComponent; }
};


DECLARE_LOG_CATEGORY_EXTERN(LogNaturalDialogTask, All, Log);

/**
 * 
 */
UCLASS(Abstract, Blueprintable)
class NATURALDIALOGSYSTEM_API UNaturalDialogTask : public UObject
{
	GENERATED_BODY()
	friend class UPlayerNaturalDialogComponent;

public:
	UNaturalDialogTask();

public:
	/** Force task finish execution */
	UFUNCTION(BlueprintCallable, Category="Natural dialog task")
	void FinishTaskExecution();

	/** Returns all player struct for external references */
	UFUNCTION(BlueprintCallable, Category="Natural dialog task")
	const FDialogTaskPlayerData& GetPlayerData() const { return CachedPlayerData; }

	/** Returns all NPC struct for external references */
	UFUNCTION(BlueprintCallable, meta=(DisplayName = "Get NPC Data"), Category="Natural dialog task")
	const FDialogTaskNPCData& GetNPCData() const { return CachedNPCData; }

	/** Returns whether this task has network authority */
	UFUNCTION(BlueprintCallable, Category="Natural dialog task")
	bool HasAuthority() const { return bHasAuthority; }

	// UObject overrides
	virtual UWorld* GetWorld() const override;
	virtual int32 GetFunctionCallspace(UFunction* Function, FFrame* Stack) override;
	virtual bool CallRemoteFunction(UFunction* Function, void* Parameters, FOutParmRec* OutParams, FFrame* Stack) override;
	virtual bool IsSupportedForNetworking() const override { return true; }
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;
	// ~ UObject overrides

	virtual void ExecuteTask(APlayerController* AskingPlayer, AActor* OwningActor);

protected:
	virtual void StartTaskExecution_Internal();
	virtual void FinishTaskExecution_Internal();
	virtual void InitializeTaskData_Internal(APlayerController* AskingPlayer, AActor* OwningActor);
	virtual bool IsTaskValid() const { return CachedPlayerData.IsValid() && CachedNPCData.IsValid(); }

	UFUNCTION(Server, WithValidation, Reliable)
	void Server_FinishTask();
	
	/**
	* Event fired when task is started
	* If we force a reply from NPC and this reply contains any task in the array, the task is then executed
	* Here can player define own logic purposes, like ask player if he take the quest from NPC, or do something (shake camera, start sequence, ...)
	* After task execution, we need call function FinishTaskExecution(), to finish task in a game
	* @Warning - NaturalDialogTask is executed on SERVER site and the task owning client
	* @param PlayerData - Stored Player external references, can be get using function GetPlayerData()
	* @param NPCData - Stored NPC external references, can be get using function GetNPCData()
	*/
	UFUNCTION(BlueprintImplementableEvent, meta = (DisplayName = "On Task Executed"), Category="Natural dialog task")
	void ReceiveOnTaskExecuted(const FDialogTaskPlayerData& PlayerData, const FDialogTaskNPCData& NPCData);

	/**
	* Executed when task is finishing execution
	* Before task object is executed and destroyed, add some finish login here, for your game
	* @Warning - NaturalDialogTask is executed only on SERVER site, not on client site
	*/
	UFUNCTION(BlueprintImplementableEvent, meta = (DisplayName = "On Task Finished"), Category="Natural dialog task")
	void ReceiveOnTaskFinished();

private:
	/** Stored external references for easy to use dialog task */
	UPROPERTY(Replicated)
	FDialogTaskPlayerData CachedPlayerData;

	/** Stored external references for easy to use dialog task */
	UPROPERTY(Replicated)
	FDialogTaskNPCData CachedNPCData;

	/** True, if the task was executed on the PC (client or server) */
	uint8 bHasStarted : 1;

	/**
	 * True, if with the object is manipulated on server, otherwise false
	 * Set on object spawn with value true
	 * Client objects contain only default false value
	 */
	uint8 bHasAuthority : 1;

	uint8 bPendingFinish : 1;
};
