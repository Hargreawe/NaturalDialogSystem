// Created by Michal Chamula. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "NaturalDialog_CoreLibrary.generated.h"

/**
 * 
 */
UCLASS()
class NATURALDIALOGSYSTEM_API UNaturalDialog_CoreLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()


public:
	/**
	 * Returns list of all data tables in a game, with dialog struct
	 * @warning - for optimization, cache this data, because this list all assets in project content, that's mean this is slow operation
	 */
	static TSet<UDataTable*> GetListOfDialogDataTables();

	
private:
	/**
	 * Find all assets of the given type recursively in project content folder
	 * @return - List of found assets references (like data tables, materials, textures, ...)
	 */
	template<typename T>
	static TArray<T*> GetListOfContentObjects_Recursive();

	/**
	 * Find asset by given file in project content folder
	 * @param File - File which we want to find in assets in format (Path/File)
	 * @return - Find result of assets reference (like data table, material, texture, ...)
	 */
	template<class T>
	static T* GetElementDataTable(const FString& File);
};

template<typename T>
TArray<T*> UNaturalDialog_CoreLibrary::GetListOfContentObjects_Recursive()
{
	TArray<T*> Result;
	Result.Reserve(10);

	const FString ElementsDir = FPaths::ProjectContentDir();

	TArray<FString> OutAssets;
	IFileManager::Get().FindFilesRecursive(OutAssets, *ElementsDir, TEXT("*"), true, false);

	for (const FString& AssetName : OutAssets)
	{
		T* LoadedAsset = GetElementDataTable<T>(AssetName);
		if (LoadedAsset)
		{
			Result.Add(LoadedAsset);
		}
	}

	return Result;
}

template<class T>
T* UNaturalDialog_CoreLibrary::GetElementDataTable(const FString& File)
{
	FString FileName;
	FString FilePath;

	int32 DotPosition = -1;
	if (File.FindLastChar('/', DotPosition))
	{
		FilePath = File.Left(DotPosition);
		FileName = File.Right(File.Len() - DotPosition - 1);
	}

	const int32 Index = FilePath.Find(TEXT("Content"));
	FilePath.RightInline(FilePath.Len() - Index - 8);

	if (FileName.FindChar('.', DotPosition))
	{
		FileName.LeftInline(DotPosition);
	}

	const FString FullName = FPaths::Combine(TEXT("/Game"), FilePath, FileName) + TEXT(".") + FileName;
	UObject* Object = StaticLoadObject(UObject::StaticClass(), nullptr, *FullName);
	return Cast<T>(Object);
}
