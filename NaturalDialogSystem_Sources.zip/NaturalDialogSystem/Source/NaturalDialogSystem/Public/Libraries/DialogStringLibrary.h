// Created by Michal Chamula. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "DialogStringLibrary.generated.h"

/**
 * 
 */
UCLASS()
class NATURALDIALOGSYSTEM_API UDialogStringLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	static FString FormatToCustomString(const FString& Input);

	static TArray<FString> SplitToSentences(const FString& Input);

private:
	// TCHAR ReplaceForLowerCase(const TCHAR Character) const;

	FORCEINLINE static bool IsSpecialChar(const TCHAR Character) { return Character < 65; }
	FORCEINLINE static bool IsTagCharacter(const TCHAR Character) { return Character == 36; }

	/** Separators are "., !, ?" */
	FORCEINLINE static bool IsSentenceSeparator(const TCHAR Character) { return Character == 33 || Character == 46 || Character == 63; }
};
