// Created by Michal Chamula. All rights reserved.

#pragma once

#include "CoreMinimal.h"

#include "Core/DictionarySubsystem.h"
#include "FunctionalClasses/DialogReplyFunction.h"
#include "Resources/Resources.h"
#include "DefaultDialogReplyFunction.generated.h"

class UPlayerNaturalDialogComponent;
class UNpcNaturalDialogComponent;


DECLARE_LOG_CATEGORY_EXTERN(Log_DefaultDialogReplyFunction, Log, All);

/**
 * 
 */
UCLASS()
class NATURALDIALOGSYSTEM_API UDefaultDialogReplyFunction : public UDialogReplyFunction, public FTickableGameObject
{
	GENERATED_BODY()

protected:
	/**
	* Curve is used for calculate metric values for reply function
	* Time (horizontal) value tels current metric value and vertical the new target value
	* If is not set, then is used basic algorithm to calculate new metric value
	*/
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category= "Properties")
	UCurveFloat* MetricCurve;

	/**
	* All invalid responses, when NPC doesnt recognize the answer
	* If not set, is used default reply text, without answer wave
	*/
	UPROPERTY(EditDefaultsOnly, meta=(RequiredAssetDataTags = "RowStructure=NaturalDialogRow_Base"), Category="Natural Dialog Component")
	UDataTable* DefaultResponses;

public:
	virtual void InitializeDialogReplyPicker() override;
	virtual bool GenerateReply(const TArray<FString>& Keywords, const UNpcNaturalDialogComponent* NpcNaturalDialogComponent, const UDataTable*& ResultTable, FName& ResultRowName) override;

	// FTickableGameObject start
	virtual void Tick(float DeltaTime) override;
	virtual TStatId GetStatId() const override;
	// ~ FTickableGameObject end

protected:
	/** Handle case when input table is registered as new data table in owner component */
	UFUNCTION()
	void HandleNewTableRegistration(const UDataTable* NewTable);

	/** Handle case when input table is removed from owner component */
	UFUNCTION()
	void HandleRegisteredTableRemoved(const UDataTable* NewTable);

private:
	FReplyData FindBestReply(const TArray<FReplyData>& AllReplies) const;
	void ModifyMetricValue(const UDataTable* InTable, const FName InRow);
	void LogMetricValues();

private:
	/**
	 * Initialized in function InitializeDialogReplyPicker()
	 * Strong ref in game instance
	 */
	TWeakObjectPtr<const UDictionarySubsystem> DictionarySubsystem;

	/**
	 * Initialized in function InitializeDialogReplyPicker()
	 * Strong ref is in UDictionarySubsystem
	 */
	TWeakObjectPtr<const UDictionaryRepresentation> DictionaryRepresentation;

	TWeakObjectPtr<UPlayerNaturalDialogComponent> OwnerComponent;

	/**
	 * #todo ... not implemented yet, @see InitializeDialogReplyPicker() function comment
	 * Cached keywords references to the tables and rows
	 * Keywords are cached only from "Ask" values in tables
	 * Optimization for reply function
	 * Keeps references where keyword can be found
	 * @Key - Keyword, we are searching for
	 * @Value - Data, where can be keyword found
	 */
	TMap<FString, FKeywordsData> CachedKeywordsData;

	/**
	 * Metric is used to compute variations for NPC reply
	 * Every data table and row is stored metric value which is decreased when the answer of the row is used
	 * When we find correct reply of two answers, we use the one with greatest metric value
	 */
	FDialogMetric Metric;
};
