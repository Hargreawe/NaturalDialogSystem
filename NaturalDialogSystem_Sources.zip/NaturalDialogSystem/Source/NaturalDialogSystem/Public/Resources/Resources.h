// Created by Michal Chamula. All rights reserved.

#pragma once

#include "CoreMinimal.h"

#include "Sound/DialogueWave.h"
#include "Resources.generated.h"

class UNaturalDialogTask;


/**
* @Key - Data table where is keyword found
*/
using FKeywordsData = TMap<const UDataTable*, TArray<FName>>;

/**
* Used for metric presentation
*/
using FDialogMetricRow = TMap<FName, float>;
using FDialogMetric = TMap<const UDataTable*, FDialogMetricRow>;


#define MIN_KEYWORDS_COUNT 3


/**
 * Struct used for table data for natural dialog system
 * Use for data table asset, to make new dialog data library for NPC
 */
USTRUCT(Blueprintable, BlueprintType)
struct FNaturalDialogRow : public FTableRowBase
{
	GENERATED_BODY()

	FNaturalDialogRow();

	/** Define the ask, which is known for NPCs */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	FText Ask;

	/** Define answer to ask, which can be replied to player */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	FText Answer;

	/**
	 * When answer is used, the sound is played as dialog wave
	 * Dialog can be used for many NPCs in game with different voices
	 * Key - Define the actor of voice
	 * Value - The voice of an actor, which is used
	 * Recommend to add default voice, if the actor is not matched, we are use it, in this case let the key nullptr 
	 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	TMap<TSoftClassPtr<AActor>, TSoftObjectPtr<UDialogueWave>> AnswerWave;

	/** Tasks will be executed, when NPC reply row answer */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	TArray<TSoftClassPtr<UNaturalDialogTask>> DialogTasks;
};

/**
* Struct used for table data with only answer
* It is used in NaturalDialogSystemComponent
* May contains data with invalid replies
*/
USTRUCT(Blueprintable, BlueprintType)
struct FNaturalDialogRow_Base : public FTableRowBase
{
	GENERATED_BODY()

	FNaturalDialogRow_Base();

	/** Define answer to ask, which can be replied to player */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	FText Answer;

	/**
	* When answer is used, the sound is played as dialog wave
	* Dialog can be used for many NPCs in game with different voices
	* Key - Define the actor of voice
	* Value - The voice of an actor, which is used
	* Recommend to add default voice, if the actor is not matched, we are use it, in this case let the key nullptr 
	*/
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	TMap<TSoftClassPtr<AActor>, TSoftObjectPtr<UDialogueWave>> AnswerWave;
};

/**
 * Used in dictionary subsystem, it holds all data of one word
 */
USTRUCT()
struct FDictionaryData
{
	GENERATED_BODY()

	FDictionaryData()
		: OccurenceCount(1) {}

	FDictionaryData(const UDataTable* InDataTable)
		: OccurenceCount(1)
	{
		TableOccurence.Add(InDataTable);
	}

	void AddOccurence(const UDataTable* InDataTable)
	{
		OccurenceCount++;
		NumOfWords++;
		TableOccurence.Add(InDataTable);
	}

	FString ToString() const
	{
		return TEXT("\n{\nOccurence: ") + FString::FromInt(OccurenceCount) + TEXT("\n}");
	}

	int32 GetOccurenceCount() const { return OccurenceCount; }
	int32 GetTableOccurenceCount() const { return TableOccurence.Num(); }
	static int32 GetNumOfWords() { return FDictionaryData::NumOfWords; }
	TSet<const UDataTable*> GetTables() const { return TableOccurence; }

	/** Used for UDictionarySubsystem, after game restarts */
	static void ResetNumOfWords() { FDictionaryData::NumOfWords = 0; }

private:
	UPROPERTY()
	TSet<const UDataTable*> TableOccurence;

	int32 OccurenceCount;

	static int32 NumOfWords;
};

struct FReplyData
{
	FReplyData()
		: NumOfMatchedKeywords(0), InTable(nullptr) {}

	FReplyData(const UDataTable* InDataTable)
		: NumOfMatchedKeywords(0), InTable(InDataTable) {}

	FReplyData(const int32 KeywordsMatchCount, const UDataTable* InDataTable, const FName InRow)
		: NumOfMatchedKeywords(KeywordsMatchCount), InTable(InDataTable), RowName(InRow) {};

	int NumOfMatchedKeywords;
	const UDataTable* InTable;
	FName RowName;


	inline bool operator==(const FReplyData& Other) const { return InTable == Other.InTable; }

	inline bool operator<(const FReplyData& Other) const { return NumOfMatchedKeywords < Other.NumOfMatchedKeywords; }

	// void operator=(const FReplyData& Other)
	// {
	// 	NumOfMatchedKeywords = Other.NumOfMatchedKeywords;
	// 	InTable = Other.InTable;
	// 	RowName = Other.RowName;
	// }
};
