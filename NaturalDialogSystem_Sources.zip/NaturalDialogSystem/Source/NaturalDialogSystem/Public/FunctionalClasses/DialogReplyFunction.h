// Created by Michal Chamula. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "DialogReplyFunction.generated.h"

class UNpcNaturalDialogComponent;
/**
 * Function trying to find the best answer for player dialog input
 * Instance is created every UNaturalDialogSystemComponent and active during game session
 * Takes keywords, returned from UDictionarySubsystem and make a reply for user using virtual function
 */
UCLASS(Abstract, Blueprintable)
class NATURALDIALOGSYSTEM_API UDialogReplyFunction : public UObject
{
	GENERATED_BODY()

public:
	/**
	* Called from UNaturalDialogSystemComponent after object creation
	* Initialize object properties before trying pickup reply
	*/
	virtual void InitializeDialogReplyPicker() {};

	/**
	 * Picks the best answer for player input using found keywords
	 * @param Keywords - Keywords from player input
	 * @param NpcNaturalDialogComponent - Npc, we are asking for reply
	 * @param ResultTable - The function result, it set the table, from where will be used answer
	 * @param ResultRowName - Index of the row of ResultTable, which row will be used
	 * @return - Returns True, if was reply found, otherwise false, then is used default data table from NaturalDialogSystemComponent
	 */
	virtual bool GenerateReply(const TArray<FString>& Keywords, const UNpcNaturalDialogComponent* NpcNaturalDialogComponent, const UDataTable*& ResultTable, FName& ResultRowName)
	{
		check(0 && "Must be overridden");
		ResultTable = nullptr;
		ResultRowName = TEXT("none");
		return false;
	}
};
